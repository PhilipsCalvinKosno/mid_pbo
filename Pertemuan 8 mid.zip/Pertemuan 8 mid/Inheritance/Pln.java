class Pln{
	String nama;
	public int tipe;
	public int pemakaian;
	public int bayar;
	public int totalharga;	
}