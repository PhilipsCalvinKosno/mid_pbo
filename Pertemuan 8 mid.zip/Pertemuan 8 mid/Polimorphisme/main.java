import java.util.Scanner;

class main {
	public static void main(String [] args){
	Scanner input = new Scanner(System.in);
	
	String name;
	int jumpemakaian;
	
	System.out.print("masukkan nama anda : ");
    name = input.nextLine();
	System.out.print("Jumlah pemakaian meteran :");
	jumpemakaian = input.nextInt();
	
	proses p = new proses(name,jumpemakaian);
	Pln l = new proses(name,jumpemakaian);
	
	p.pilihan();
	p.pembayaran();
	p.cetak();
	
	
		
	}
}